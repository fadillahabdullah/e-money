<?php $tabeldata = "Petugas"; ?>

<div class="panel">
    <header class="panel-heading">
        <div class="panel-actions">
            <button type="button" 
                    data-toggle="modal" data-target="#ModalTambah" class="btn btn-round btn-success btn-sm ">Tambah Data
            </button>
        </div>
        <h3 class="panel-title">Data Petugas</h3>
    </header>
    <div class="panel-body">
        <table class="table table-hover dataTable table-striped w-full" data-plugin="dataTable">
            <thead>
                <tr>
                    <th style="width: 12%">ID Petugas<br>Status</th>
                    <th style="width: 20%">Nama Petugas</th>
                    <th style="width: 20%">Alamat</th>
                    <th style="width: 23%">Operasi</th>
                </tr>
        </thead>
            <tbody>
    <?php
                    $sql = "SELECT * FROM e_petugas ORDER BY id_petugas";
                    $tampil = mysqli_query($koneksi, $sql);
                    while ($z = mysqli_fetch_array($tampil)){ 
                        $id = $z["id_petugas"];
                        $nm = $z["nm_petugas"];
                        $alm = $z["alamat"];
                        $stt = $z["status"];
                        if($stt==1){
                            $sttt = "Aktif";
                            $warna = "success";
                            $tujuanmodal = "#ModalTidakAktif";
                        }else{
                            $sttt = "Tidak Aktif";
                            $warna = "danger";
                            $tujuanmodal = "#ModalAktif";
                        }
                        echo "<tr>";
                            echo "<td>$id<br><span class='badge badge-$warna'>$sttt</span></td>";
                            echo "<td>$nm</td>";
                            echo "<td>$alm</td>";
                            echo "<td>"
                ?>
                                <button type="button" data-toggle="modal" data-target="<?= $tujuanmodal ?>"
                                    onclick="status('<?= $id; ?>')"
                                    class="btn btn-<?= $warna; ?> btn-success btn-sm" style="margin-bottom:5px;">Status
                                </button>
                                <button type="button" data-toggle="modal" data-target="#ModalReset"
                                    onclick="reset('<?= $id; ?>')"
                                    class="btn btn-primary btn-success btn-sm" style="margin-bottom:5px;">Reset
                                </button>
                                <button type="button" data-toggle="modal" data-target="#ModalEdit"
                                    onclick="edit('<?= $id; ?>',
                                                  '<?= $nm; ?>',
                                                  '<?= $alm; ?>')"
                                    class="btn btn-info btn-success btn-sm" style="margin-bottom:5px;">Edit
                                </button>
                                <button type="button" data-toggle="modal" data-target="#ModalHapus"
                                    onclick="hapus('<?= $id; ?>',
                                                   '<?= $nm; ?>',
                                                   '<?= $alm; ?>')"
                                    class="btn btn-danger btn-success btn-sm" style="margin-bottom:5px;">Hapus
                                </button>
                                <button type="submit" class="btn btn-round btn-success btn-sm" name="btncetak">Cetak</button>
               
                <?php
                            echo "</td>";
                        echo "</tr>";
                    }
                ?>
            </tbody>
        </table>
    </div>
 <!--MODAL TAMBAH DATA-->
    <div class="modal fade modal-success" id="ModalTambah" aria-hidden="true" role="dialog" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Tambah Data Petugas</h4>
                </div>
                <form method="post">
                    <div class="modal-body">
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label>ID Petugas</label>
                                <input type="text" class="form-control" value="{Otomatis By Sistem}" readonly>
                            </div>
                            <div class="form-group col-md-12">
                                <label>Nama Petugas</label>
                                <input type="text" class="form-control" name="txtnama" placeholder="ex : Fadil" required autocomplete="off">
                            </div>
                            <div class="form-group col-md-12">
                                <label>Alamat</label>
                                <textarea class="form-control" name="txtalm" placeholder="ex : Dsn.tambakberas RT.03 RW.04 tambakrejo Kab. Jombang" autocomplete="off"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-pure" data-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary" name="btntambah">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!--TAMBAH DATA PHP-->
    <?php
        if (isset($_REQUEST["btntambah"])){
            $j = strtotime(date("YmdHis"));
            $k = $_REQUEST["txtnama"];
            $o = $_REQUEST["txtalm"];
            $pas = simple_encrypt($j);
            $q = "0";
            $SQL = "INSERT INTO e_petugas VALUES ('$j','$k','$pas','$o','$q')";
            $ProsesSimpan = mysqli_query($koneksi, $SQL);
            if ($ProsesSimpan){
                $isilog = "ID Petugas = $j,\n Nama Petugas = $k,\n Alamat = $o,\n Status = Tidak Aktif";
                tambah_log($tabeldata,'Tambah', $isilog, $iduser);
                echo "<script>
                  swal({
                      title: 'Simpan Berhasil',
                      text: 'Data Berhasil di Tambahkan',
                      type: 'success',
                      showCancelButton: false,
                      confirmButtonClass: 'btn-success',
                      confirmButtonText: 'OK',
                      closeOnConfirm: false
                  }, function () {window.location = '';});
                  </script>";
            } else {
                  echo "<script>
                  swal({
                      title: 'Simpan Gagal',
                      text: 'Periksa Kembali Isian Anda',
                      type: 'error',
                      showCancelButton: false,
                      confirmButtonClass: 'btn-success',
                      confirmButtonText: 'OK',
                      closeOnConfirm: false
                  });
                  </script>";
            }
        }
    ?>
<!--MODAL EDIT DATA-->
    <div class="modal fade modal-info" id="ModalEdit" aria-hidden="true" role="dialog" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Edit Data Petugas</h4>
                </div>
                <form method="post">
                    <div class="modal-body">
                        <div class="row">
                            <div class="form-group col-md-4">
                                <label>ID Petugas</label>
                                <input type="text" class="form-control" name="txtide" id="txtide" required readonly>
                            </div>
                            <div class="form-group col-md-10">
                                <label>Nama Petugas</label>
                                <input type="text" class="form-control" name="txtnamae" id="txtnamae" placeholder="ex : Fadil" required>
                            </div>
                            <div class="form-group col-md-12">
                                <label>Alamat</label>
                                <textarea class="form-control" name="txtalme" id="txtalme" placeholder="ex : Dsn.tambakberas RT.03 RW.04 tambakrejo Kab. Jombang" required></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-pure" data-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary" name="btnedit">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!--UPDATE DATA PHP-->
    <?php
        if (isset($_REQUEST["btnedit"])){
            $j = $_REQUEST["txtide"];
            $k = $_REQUEST["txtnamae"];
            $o = $_REQUEST["txtalme"];
            $SQL = "UPDATE e_petugas SET nm_petugas = '$k', alamat = '$o' WHERE id_petugas = '$j'";
            $ProsesSimpan = mysqli_query($koneksi, $SQL);
            if ($ProsesSimpan){
                $isilog = "ID Petugas = $j,\n Nama Petugas = $k,\n Alamat = $o";
                tambah_log($tabeldata,'Update', $isilog, $iduser);
                echo "<script>
                  swal({
                      title: 'Update Berhasil',
                      text: 'Data Berhasil di Update',
                      type: 'success',
                      showCancelButton: false,
                      confirmButtonClass: 'btn-success',
                      confirmButtonText: 'OK',
                      closeOnConfirm: false
                  }, function () {window.location = '';});
                  </script>";
            } else {
                  echo "<script>
                  swal({
                      title: 'Update Gagal',
                      text: 'Periksa Kembali Isian Anda',
                      type: 'error',
                      showCancelButton: false,
                      confirmButtonClass: 'btn-success',
                      confirmButtonText: 'OK',
                      closeOnConfirm: false
                  });
                  </script>";
            }
        }
    ?>
 <!--MODAL HAPUS DATA-->
    <div class="modal fade modal-danger" id="ModalHapus" aria-hidden="true" role="dialog" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Hapus Data Petugas</h4>
                </div>
                <form method="post">
                    <div class="modal-body">
                        <div class="row">
                            <input type="hidden" id="txtidh" name="txtidh">
                            <input type="hidden" id="txtnamah" name="txtnamah">
                            <input type="hidden" id="txtalmh" name="txtalmh">
                            <div class="form-group col-md-12">
                                <p>Anda Yakin Ingin Menghapus Data Petugas Ini ?</p>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-pure" data-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary" name="btnhapus">Hapus</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!--HAPUS DATA PHP-->
    <?php
        if (isset($_REQUEST["btnhapus"])){
            $j = $_REQUEST["txtidh"];
            $k = $_REQUEST["txtnamah"];
            $o = $_REQUEST["txtalmh"];
            $SQL = "DELETE FROM e_petugas WHERE id_petugas = '$j'";
            $ProsesSimpan = mysqli_query($koneksi, $SQL);
            if ($ProsesSimpan){
                $isilog = "ID Petugas = $j,\n Nama Petugas = $k,\n Alamat = $o";
                tambah_log($tabeldata,'Hapus', $isilog, $iduser);
                echo "<script>
                  swal({
                      title: 'Hapus Berhasil',
                      text: 'Data Berhasil di Hapus',
                      type: 'success',
                      showCancelButton: false,
                      confirmButtonClass: 'btn-success',
                      confirmButtonText: 'OK',
                     SantrieOnConfirm: false
                  }, function () {window.location = '';});
                  </script>";
            } else {
                  echo "<script>
                  swal({
                      title: 'Hapus Gagal',
                      texSantrieriksa Kembali Data Anda',
                      type: 'error',
                      showCancelButton: false,
                      confirmButtonClass: 'btn-success',
                      confirmButtonText: 'OK',
                      closeOnConfirm: false
                  });
                  </script>";
            }
        }
    ?>
 <!--MODAL AKTIFKAN-->
    <div class="modal fade modal-danger" id="ModalAktif" aria-hidden="true" role="dialog" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Aktifkan Petugas</h4>
                </div>
                <form method="post">
                    <div class="modal-body">
                        <div class="row">
                            <input type="hidden" id="txtida" name="txtida">
                            <div class="form-group col-md-12">
                                <p>Anda Yakin Ingin Mengaktifkan Petugas Ini ?</p>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-pure" data-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary" name="btnaktif">Ya</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!--AKTIFKAN DATA PHP-->
    <?php
        if (isset($_REQUEST["btnaktif"])){
            $j = $_REQUEST["txtida"];
            $SQL = "UPDATE e_petugas SET status = '1' WHERE id_petugas = '$j'";
            $ProsesSimpan = mysqli_query($koneksi, $SQL);
            if ($ProsesSimpan){
                $isilog = "Petugas dengan ID = $j Telah di Aktifkan";
                tambah_log($tabeldata,'Update', $isilog, $iduser);
                echo "<script>
                  swal({
                      title: 'Update Berhasil',
                      text: 'Data Berhasil di Update',
                      type: 'success',
                      showCancelButton: false,
                      confirmButtonClass: 'btn-success',
                      confirmButtonText: 'OK',
                      closeOnConfirm: false
                  }, function () {window.location = '';});
                  </script>";
            } else {
                  echo "<script>
                  swal({
                      title: 'Update Gagal',
                      text: 'Data Gagal di Update',
                      type: 'error',
                      showCancelButton: false,
                      confirmButtonClass: 'btn-success',
                      confirmButtonText: 'OK',
                      closeOnConfirm: false
                  });
                  </script>";
            }
        }
    ?>

    <!--MODAL TIDAK AKTIFKAN-->
    <div class="modal fade modal-success" id="ModalTidakAktif" aria-hidden="true" role="dialog" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Non Aktifkan Petugas</h4>
                </div>
                <form method="post">
                    <div class="modal-body">
                        <div class="row">
                            <input type="hidden" id="txtidta" name="txtidta">
                            <div class="form-group col-md-12">
                                <p>Anda Yakin Ingin Menon-Aktifkan Petugas Ini ?</p>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-pure" data-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary" name="btnnonaktif">Ya</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!--NON AKTIFKAN DATA PHP-->
    <?php
        if (isset($_REQUEST["btnnonaktif"])){
            $j = $_REQUEST["txtidta"];
            $SQL = "UPDATE e_petugas SET status = '0' WHERE id_petugas = '$j'";
            $ProsesSimpan = mysqli_query($koneksi, $SQL);
            if ($ProsesSimpan){
                $isilog = "Petugas dengan ID = $j Telah di Non Aktifkan";
                tambah_log($tabeldata,'Update', $isilog, $iduser);
                echo "<script>
                  swal({
                      title: 'Update Berhasil',
                      text: 'Data Berhasil di Update',
                      type: 'success',
                      showCancelButton: false,
                      confirmButtonClass: 'btn-success',
                      confirmButtonText: 'OK',
                      closeOnConfirm: false
                  }, function () {window.location = '';});
                  </script>";
            } else {
                  echo "<script>
                  swal({
                      title: 'Update Gagal',
                      text: 'Data Gagal di Update',
                      type: 'error',
                      showCancelButton: false,
                      confirmButtonClass: 'btn-success',
                      confirmButtonText: 'OK',
                      closeOnConfirm: false
                  });
                  </script>";
            }
        }
    ?>

      <!--MODAL RESET-->
    <div class="modal fade modal-primary" id="ModalReset" aria-hidden="true" role="dialog" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Reset Password Petugas</h4>
                </div>
                <form method="post">
                    <div class="modal-body">
                        <div class="row">
                            <input type="hidden" id="txtidr" name="txtidr">
                            <div class="form-group col-md-12">
                                <p>Anda Yakin Ingin Me-Reset Password Petugas Ini ?</p>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-pure" data-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary" name="btnreset">Ya</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!--RESET PASSWORD PHP-->
    <?php
        if (isset($_REQUEST["btnreset"])){
            $j = $_REQUEST["txtidr"];
            $k = simple_encrypt($j);
            $SQL = "UPDATE e_petugas SET password = '$k' WHERE id_petugas = '$j'";
            $ProsesSimpan = mysqli_query($koneksi, $SQL);
            if ($ProsesSimpan){
                $isilog = "Reset Password Petugas ID = $j";
                tambah_log($tabeldata,'Update', $isilog, $iduser);
                echo "<script>
                  swal({
                      title: 'Update Berhasil',
                      text: 'Reset Password Berhasil',
                      type: 'success',
                      showCancelButton: false,
                      confirmButtonClass: 'btn-success',
                      confirmButtonText: 'OK',
                      closeOnConfirm: false
                  }, function () {window.location = '';});
                  </script>";
            } else {
                  echo "<script>
                  swal({
                      title: 'Update Gagal',
                      text: 'Reset Password Gagal',
                      type: 'error',
                      showCancelButton: false,
                      confirmButtonClass: 'btn-success',
                      confirmButtonText: 'OK',
                      closeOnConfirm: false
                  });
                  </script>";
            }
        }
    ?>


</div>
    <script>
    function edit(a, b, c){
        $("#txtide").val(a);
        $("#txtnamae").val(b);
        $("#txtalme").val(c);
    }

    function hapus(a, b, c){
        $("#txtidh").val(a);
        $("#txtnamah").val(b);
        $("#txtalmh").val(c);
    }

    function status(a){
        $("#txtida").val(a);
        $("#txtidta").val(a);
    }

    function reset(a){
        $("#txtidr").val(a);
    }
</script>