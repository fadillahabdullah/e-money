<?php
	function tgl_indo($tgl_en){
		$tgl = substr($tgl_en, 8, 2);
     	$thn = substr($tgl_en, 0, 4);
     	//------------------------------------------------------------------------
     	$hr = date("w", strtotime($tgl_en));
    	$hr2 = array('Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu');
    	$hari = $hr2[$hr];
    	//------------------------------------------------------------------------
     	switch(substr($tgl_en, 5, 2)){
    		case "01":
    			$bln = "Jan";
    			break;
    		case "02":
    			$bln = "Feb";
    			break;
    		case "03":
    			$bln = "Mar";
    			break;
    		case "04":
    			$bln = "Apr";
    			break;
    		case "05":
    			$bln = "Mei";
    			break;
    		case "06":
    			$bln = "Jun";
    			break;
    		case "07":
    			$bln = "Jul";
    			break;
    		case "08":
    			$bln = "Agu";
    			break;
    		case "09":
    			$bln = "Sep";
    			break;
    		case "10":
    			$bln = "Okt";
    			break;
    		case "11":
    			$bln = "Nov";
    			break;
    		default:
    			$bln = "Des";
    			break;
    	}
    	return $hari.", ".$tgl." ".$bln." ".$thn;
	}

    function tgl_in($tgl_en){
        $tgl = substr($tgl_en, 8, 2);
        $thn = substr($tgl_en, 0, 4);
        //------------------------------------------------------------------------
        switch(substr($tgl_en, 5, 2)){
            case "01":
                $bln = "Jan";
                break;
            case "02":
                $bln = "Feb";
                break;
            case "03":
                $bln = "Mar";
                break;
            case "04":
                $bln = "Apr";
                break;
            case "05":
                $bln = "Mei";
                break;
            case "06":
                $bln = "Jun";
                break;
            case "07":
                $bln = "Jul";
                break;
            case "08":
                $bln = "Agu";
                break;
            case "09":
                $bln = "Sep";
                break;
            case "10":
                $bln = "Okt";
                break;
            case "11":
                $bln = "Nov";
                break;
            default:
                $bln = "Des";
                break;
        }
        return $tgl." ".$bln." ".$thn;
    }

?>