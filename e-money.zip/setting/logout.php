<?php
	session_start();
	session_unset('33DweMB');
?>