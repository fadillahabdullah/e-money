<?php $tabeldata = "TransaksiMasuk"; ?>
<div class="panel">
  <header class="panel-heading">
    <div class="panel-actions">
      <button type="button" data-toggle="modal" data-target="#ModalTambah"
      class="btn btn-round btn-success btn-sm" onclick="refresh()">Tambah Data
      </button>
    </div>
    <h3 class="panel-title">Data Transaksi Masuk</h3>
  </header>
  <div class="panel-body">
    <table class="table table-hover dataTable table-striped w-full" data-plugin="dataTable">
      <thead>
        <tr>
          <th style="width: 12%">ID</th>
          <th style="width: 13%">ID Santri</th>
          <th style="width: 10%">Jam</th>
          <th style="width: 15%">Tanggal</th>
          <th style="width: 15%">Nominal</th>
          <th style="width: 15%">Keterangan</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $sql = "SELECT * FROM e_trans_masuk ORDER BY id";
        $tampil = mysqli_query($koneksi, $sql);
        while ($z = mysqli_fetch_array($tampil)){
        $id = $z["id"];
        $idsantri = $z["id_santri"];
        $nama = $z["nm_santri"];
        $jam = $z["jam"];
        $tanggal = $z["tanggal"];
        $nominal = $z["nominal"];
        $keterangan = $z["keterangan"];
        echo "<tr>";
          echo "<td>$id<br><span class='badge badge-$warna'>$sttt</span></td>";
          echo "<td>$idsantri</td>";
          echo "<td>$jam</td>";
          echo "<td>".tgl_in($tanggal)."</td>";
          echo "<td>$nominal</td>";
          echo "<td>$keterangan</td>";
        ?>
        <?php
          echo "</td>";
          echo "</tr>";
        }
        ?>
      </tbody>
    </table>
  </div>
  <!--MODAL TAMBAH DATA-->
  <div class="modal fade modal-success" id="ModalTambah" aria-hidden="true" role="dialog" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Tambah Data Transaksi Masuk</h4>
        </div>
        <form method="post">
          <div class="modal-body">
            <div class="row">
              <div class="form-group col-md-6">
                <label>ID</label>
                <input type="text" class="form-control" id="txtkd" maxlength="10" pattern="[1-9]" autocomplete="off" onchange="carisantri()" onkeyup="carisantri()">
              </div>
              <div class="form-group col-md-6">
                <label>ID Santri</label>
                <input type="text" class="form-control" id="txtidsantri" placeholder="ex: 197067266514" readonly>
              </div>
              <div class="form-group col-md-6">
                <label>Nama Santri</label>
                <input type="text" class="form-control" id="txtnama" placeholder="ex: Fadil" readonly>
              </div>
              <div hidden class="form-group col-md-6">
                <label>PIN</label>
                <input type="password" class="form-control" id="txtpin" placeholder="ex: ***" readonly>
              </div>
              <div class="form-group col-md-6">
                <label>Saldo Terakhir</label>
                <input type="text" class="form-control" id="txtsaldo" placeholder="ex: 100000" readonly>
              </div>
              <div class="form-group col-md-6">
                <label>PIN</label>
                <input type="password" class="form-control" id="txtpin2" placeholder="ex: ***">
              </div>
              <div class="form-group col-md-6">
                <label>Keterangan</label>
                <input type="text" class="form-control" id="txtketerangan" placeholder="ex: keterangan">
              </div>
              <div class="form-group col-md-12">
                <label>Nominal</label>
                <input type="number" class="form-control" id="txtnominal" placeholder="ex: 800000" style="font-size: 35px; height: 37px;">
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default btn-pure" data-dismiss="modal">Batal</button>
            <button type="button" class="btn btn-primary" onclick="simpandata()">Simpan</button>
          </div>
        </form>
      </div>
    </div>
  </div>
  <!--TAMBAH DATA PHP-->
  <?php
  if (isset($_REQUEST["btntambah"])){
  $j = strtotime(date("YmdHis"));
  $jam = date("H:i:s");
  $tgl = date("Y-m-d");
  $id = $_REQUEST["txtidsantri"];
  $m = $_REQUEST["txtnominal"];
  $keterangan = $_REQUEST["txtketerangan"];
  $pin1 = $_REQUEST["txtpin"];
  $pin2 = $_REQUEST["txtpin2"];
  if($pin1 != $pin2){
  echo "<script>
  swal({
  title: 'Simpan Gagal',
  text: 'Pin anda salah',
  type: 'error',
  showCancelButton: false,
  confirmButtonClass: 'btn-success',
  confirmButtonText: 'OK',
  closeOnConfirm: false
  });
  </script>";
  return;
  }
  $SQL = "INSERT INTO e_trans_masuk VALUES('$j','$id','$jam','$tgl','$m','$keterangan')";
  $ProsesSimpan = mysqli_query($koneksi, $SQL);
  if ($ProsesSimpan){
  $isilog = "ID = $kd,\n ID Santri = $id,\n Nama = $nama,\n Jam = $l,\n saldo terakhir = $sal,\n Nominal = $m,\n Keterangan = $n";
  tambah_log($tabeldata,'Tambah', $isilog, $iduser);
  echo "<script>
  swal({
  title: 'Simpan Berhasil',
  text: 'Data Berhasil di Tambahkan',
  type: 'success',
  showCancelButton: false,
  confirmButtonClass: 'btn-success',
  confirmButtonText: 'OK',
  closeOnConfirm: false
  }, function () {window.location = '';});
  </script>";
  } else {
  echo "<script>
  swal({
  title: 'Simpan Gagal',
  text: 'Periksa Kembali Isian Anda',
  type: 'error',
  showCancelButton: false,
  confirmButtonClass: 'btn-success',
  confirmButtonText: 'OK',
  closeOnConfirm: false
  });
  </script>";
  }
  }
  ?>
</div>
<script>
function simpandata(){
var id = $("#txtidsantri").val();
var m = $("#txtnominal").val();
var ket = $("#txtketerangan").val();
var pin = $("#txtpin").val();
var pin2 = $("#txtpin2").val();
if(id == "" || pin2 == "" || m == "" || m == 0){
swal({
title: 'Simpan Gagal',
text: 'Ada Isian yang Belum diisi',
type: 'error',
showCancelButton: false,
confirmButtonClass: 'btn-success',
confirmButtonText: 'OK',
closeOnConfirm: false
});
return;
}
if(pin != pin2){
swal({
title: 'Simpan Gagal',
text: 'PIN tidak Sesuai',
type: 'error',
showCancelButton: false,
confirmButtonClass: 'btn-success',
confirmButtonText: 'OK',
closeOnConfirm: false
});
return;
}
$.ajax({
url: "ajax/1111.php",
method: "POST",
data: {id: id, m: m, ket: ket},
cache: false,
success: function(x){
if(x == 1){
swal({
title: 'Simpan Berhasil',
text: 'Data Berhasil di Tambahkan',
type: 'success',
showCancelButton: false,
confirmButtonClass: 'btn-success',
confirmButtonText: 'OK',
closeOnConfirm: false
}, function(){
window.location = '';
});
}else{
swal({
title: 'Simpan Gagal',
text: 'Penambahan Saldo Gagal',
type: 'error',
showCancelButton: false,
confirmButtonClass: 'btn-success',
confirmButtonText: 'OK',
closeOnConfirm: false
});
}

}
})
}
function carisantri(){
var a = $("#txtkd").val();
$.ajax({
url: "ajax/4700.php",
method: "POST",
data: {a: a},
cache: false,
success: function(x){
var r = x.split("|");
$("#txtidsantri").val(r[0]);
$("#txtnama").val(r[1]);
$("#txtsaldo").val(r[2]);
$("#txtpin").val(r[3]);
}
})
}
//refresh
 function refresh(){
$("#txtkd").val("");
$("#txtidsantri").val("");
$("#txtnama").val("");
$("#txtpin").val("");
$("#txtsaldo").val("");
$("#txtpin2").val("");
$("#txtketerangan").val("");
$("#txtnominal").val("");
}
function hapus(a, b, c, d, e, f){
$("#txtidh").val(a);
$("#txtidsantrih").val(b);
$("#txtjamh").val(c);
$("#txttanggalh").val(d);
$("#txtnominalh").val(e);
$("#txtketerangan").val(f);
}
</script>