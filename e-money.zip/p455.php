<div class="modal fade modal-primary" id="ModalPassword" aria-hidden="true" role="dialog" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Ubah Password Pengguna</h4>
                    </div>
                    <form method="post">
                        <div class="modal-body">
                            <div class="form-group">
                                <div class="input-group input-group-icon">
                                    <span class="input-group-addon">
                                        <span class="icon ti-check" aria-hidden="true"></span>
                                    </span>
                                    <input type="password" class="form-control" name="txtpasslama" placeholder="Password Lama">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group input-group-icon">
                                    <span class="input-group-addon">
                                        <span class="icon ti-check" aria-hidden="true"></span>
                                    </span>
                                    <input type="password" class="form-control" name="txtpassbaru" placeholder="Password Baru">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group input-group-icon">
                                    <span class="input-group-addon">
                                        <span class="icon ti-check" aria-hidden="true"></span>
                                    </span>
                                    <input type="password" class="form-control" name="txtpasskonf" placeholder="Konfirmasi Password Baru">
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default btn-pure" data-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-primary" name="btnupdateps">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>