<?php $tabeldata = "Transaksi"; ?>

<div class="panel">
    <header class="panel-heading">
        <h3 class="panel-title">Data Transaksi</h3>
    </header>
    <div class="panel-body">
        <table class="table table-hover dataTable table-striped w-full" data-plugin="dataTable">
            <thead>
                <tr>
                    <th style="width: 15%">ID Transaksi</th>
                    <th style="width: 20%">Nama Toko</th>
                    <th style="width: 15%">Tanggal</th>
                    <th style="width: 15%">Jam</th>
                    <th style="width: 15%">Status Diterima</th>
                    <th style="width: 20%">Operasi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $sql = "SELECT a.*, b.nama_toko AS nama FROM transaksi AS a LEFT JOIN pelanggan AS b ON a.id_pelanggan = b.id ORDER BY id";
                    $tampil = mysqli_query($koneksi, $sql);
                    while ($z = mysqli_fetch_array($tampil)){ 
                        $id = $z["id"];
                        $idp = $z["nama"];
                        $tgl = $z["tgl"];
                        $jam = $z["jam"];
                        $stt = $z["status_diterima"];
                        if($stt==1){
                            $stt = "Diterima";
                            $warna = "success";
                        }else{
                            $stt = "Belum Diterima";
                            $warna = "danger";
                        }
                        echo "<tr>";
                            echo "<td>$id</td>";
                            echo "<td>$idp</td>";
                            echo "<td>$tgl</td>";
                            echo "<td>$jam</td>";
                            echo "<td><span class='badge badge-$warna'>$stt</span></td>";
                            echo "<td>"
                ?>
                                <button type="button" data-toggle="modal" data-target="#ModalEdit"
                                    onclick="edit('<?= $id; ?>',
                                                  '<?= $idp; ?>',
                                                  '<?= $tgl; ?>',
                                                  '<?= $jam; ?>',
                                                  '<?= $stt; ?>')"
                                    class="btn btn-info btn-success btn-sm" style="margin-bottom:5px;">Edit
                                </button>
                                <button type="button" data-toggle="modal" data-target="#ModalHapus"
                                    onclick="hapus('<?= $id; ?>',
                                                  '<?= $idp; ?>',
                                                  '<?= $tgl; ?>',
                                                  '<?= $jam; ?>',
                                                  '<?= $stt; ?>')"
                                    class="btn btn-danger btn-success btn-sm " style="margin-bottom:5px;">Hapus
                                </button>
                                <button type="submit" data-toggle="modal" data-target="#ModalDetail"
                                    class="btn btn-round btn-success btn-sm " onclick="detail('<?= $id; ?>')">Detail
                                </button>
                <?php
                            echo "</td>";
                        echo "</tr>";
                    }
                ?>
            </tbody>
        </table>
    </div>

    <!--MODAL DETAIL-->
    <div class="modal fade modal-success" id="ModalDetail" aria-hidden="true" role="dialog" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Detail Barang</h4>
                </div>
                <form method="post">
                    <div class="modal-body">
                        <div class="row">
                            <div class="form-group col-md-12" id="blokpertanyaan"></div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-pure" data-dismiss="modal">OK</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


    <!--MODAL EDIT DATA-->
    <div class="modal fade modal-info" id="ModalEdit" aria-hidden="true" role="dialog" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Edit Data Transaksi</h4>
                </div>
                <form method="post">
                    <div class="modal-body">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <label>ID Transaksi</label>
                                <input type="text" class="form-control" name="txtide" id="txtide" required>
                            </div>
                            <div class="form-group col-md-6">
                                <label>ID Pelanggan</label>
                                    <select class="form-control" name="txtidpe" id="txtidpe" required>
                                        <option value="">--{Pilih Pelanggan}--</option>
                                          <?php
                                              $sql = "SELECT * FROM pelanggan ORDER BY id";
                                              $tampil = mysqli_query($koneksi, $sql);
                                              while ($z = mysqli_fetch_array($tampil)){ 
                                                  $idp = $z["id"];
                                                  $nmt = $z["nama_toko"];
                                                  echo "<option value='$idp'>$idp, $nmt</option>";
                                              }
                                          ?>
                                    </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label>Status Diterima</label>
                                <select class="form-control" name="txtstte" id="txtstte" required>
                                        <option value="">--{Pilih Status}--</option>
                                        <option value="0">Belum Diterima</option>
                                    <option value="1">Diterima</option>
                                    </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-pure" data-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary" name="btnedit">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!--UPDATE DATA PHP-->
    <?php
        if (isset($_REQUEST["btnedit"])){
            $j = $_REQUEST["txtide"];
            $k = $_REQUEST["txtidpe"];
            $l = date("Y-m-d");
            $m = date("H:i:s");
            $n = $_REQUEST["txtstte"];
            $SQL = "UPDATE transaksi SET id_pelanggan = '$k', tgl = '$l', jam = '$m', status_diterima = '$n' WHERE id = '$j'";
            $ProsesSimpan = mysqli_query($koneksi, $SQL);
            if ($ProsesSimpan){
                $isilog = "ID Transaksi = $j,\n ID Pelanggan = $k,\n Status Diterima = $n";
                tambah_log($tabeldata,'Update', $isilog, $iduser);
                echo "<script>
                  swal({
                      title: 'Update Berhasil',
                      text: 'Data Berhasil di Update',
                      type: 'success',
                      showCancelButton: false,
                      confirmButtonClass: 'btn-success',
                      confirmButtonText: 'OK',
                      closeOnConfirm: false
                  }, function () {window.location = '';});
                  </script>";
            } else {
                  echo "<script>
                  swal({
                      title: 'Update Gagal',
                      text: 'Periksa Kembali Isian Anda',
                      type: 'error',
                      showCancelButton: false,
                      confirmButtonClass: 'btn-success',
                      confirmButtonText: 'OK',
                      closeOnConfirm: false
                  });
                  </script>";
            }
        }
    ?>

    <!--MODAL HAPUS DATA-->
    <div class="modal fade modal-danger" id="ModalHapus" aria-hidden="true" role="dialog" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Hapus Data Transaksi</h4>
                </div>
                <form method="post">
                    <div class="modal-body">
                        <div class="row">
                            <input type="hidden" id="txtidh" name="txtidh">
                            <input type="hidden" id="txtidph" name="txtnamah">
                            <input type="hidden" id="txttglh" name="txtklhh">
                            <input type="hidden" id="txtjamh" name="txttlhh">
                            <input type="hidden" id="txtstth" name="txttlph">
                            <div class="form-group col-md-12">
                                <p>Anda Yakin Ingin Menghapus Data Transaksi Ini ?</p>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-pure" data-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary" name="btnhapus">Hapus</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!--HAPUS DATA PHP-->
    <?php
        if (isset($_REQUEST["btnhapus"])){
            $j = $_REQUEST["txtidh"];
            $k = $_REQUEST["txtidph"];
            $l = date("Y-m-d");
            $m = date("H:i:s");
            $n = $_REQUEST["txtstth"];
            $SQL = "DELETE FROM transaksi WHERE id = '$j'";
            $ProsesSimpan = mysqli_query($koneksi, $SQL);
            if ($ProsesSimpan){
                $isilog = "ID Transaksi = $j,\n ID Pelanggan = $k,\n Tanggal = $l,\n Jam = $m,\n Status Diterima = $n";
                tambah_log($tabeldata,'Hapus', $isilog, $iduser);
                echo "<script>
                  swal({
                      title: 'Hapus Berhasil',
                      text: 'Data Berhasil di Hapus',
                      type: 'success',
                      showCancelButton: false,
                      confirmButtonClass: 'btn-success',
                      confirmButtonText: 'OK',
                      closeOnConfirm: false
                  }, function () {window.location = '';});
                  </script>";
            } else {
                  echo "<script>
                  swal({
                      title: 'Hapus Gagal',
                      text: 'Periksa Kembali Data Anda',
                      type: 'error',
                      showCancelButton: false,
                      confirmButtonClass: 'btn-success',
                      confirmButtonText: 'OK',
                      closeOnConfirm: false
                  });
                  </script>";
            }
        }
    ?>


<script>
    function edit(a, b, c, d, e){
        $("#txtide").val(a);
        $("#txtidpe").val(b);
        $("#txttgle").val(c);
        $("#txtjame").val(d);
        $("#txtstte").val(e);
    }

    function hapus(a, b, c, d, e){
        $("#txtidh").val(a);
        $("#txtidph").val(b);
        $("#txttglh").val(c);
        $("#txtjamh").val(d);
        $("#txtstth").val(e);
    }

    function detail(a){
        $("#txtbarang").val(a);
        $.ajax({
            url: "ajax/4444.php",
            data: "id=" + a,
            cache: false, 
            success: function(msg){
                $("#blokpertanyaan").html(msg);
            }
        })
    }
</script>