 <?php
    include "../../setting/mpdf60/mpdf.php";
    include "../../setting/koneksi.php";
    $mpdf = new mPDF("utf-8","A4");
    //$stylesheet = file_get_contents('tema.css');
    session_start();
    $nilai = $_SESSION["cetak_transaksi_pilih"];
    ob_start();
 ?>

    <center> <h2>Cetak Transaksi</h2></center>
    <table border="1">
       

        <?php 
            //$no = 0;
            $SQL = mysqli_query($koneksi, "SELECT * FROM v_transaksi2 where id = '$nilai'");
            while ($x = mysqli_fetch_array($SQL)) {

                //$no++;
                $id = $x["id"];
                $idp = $x["id_pelanggan"];
                $nmt = $x["nama_toko"];
                $tgl = $x["tgl"&"jam"];
                $jj = $x["jumlah_jenis"];
                $jh = $x["jumlah_harga"];
                $jb = $x["jumlah_bayar"];
                $jk = $x["jumlah_kurang"];
                $stb = $x["status_bayar"];
                $sdt = $x["status_diterima"];
                echo "<tr>
                <td>ID Transaksi<br>ID Pelanggan<br>Waktu<br>Jumlah Jenis<br>Jumlah Harga<br>Jumlah Bayar<br>Jumlah Kurang<br>Status Bayar<br>Status Diterima</td>
                <td>$id<br>$idp<br>$nmt<br>$tgl<br>$jj<br>$jh<br>$jb<br>$jk<br>$stb<br>$sdt</td>
                </tr>";
            }
        ?>
    </table>

    <?php
        $isi = ob_get_contents();   
        ob_end_clean();
        $mpdf->WriteHTML($isi);
        $mpdf->Output("test.pdf", "I");
        exit;
    ?>

