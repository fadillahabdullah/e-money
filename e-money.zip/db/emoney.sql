-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 12 Mar 2019 pada 09.37
-- Versi Server: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `emoney`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `e_admin`
--

CREATE TABLE IF NOT EXISTS `e_admin` (
  `id` varchar(25) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `alamat` longtext NOT NULL,
  `kelahiran` varchar(50) NOT NULL,
  `telp` varchar(25) NOT NULL,
  `status` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `e_admin`
--

INSERT INTO `e_admin` (`id`, `nama`, `password`, `tgl_lahir`, `alamat`, `kelahiran`, `telp`, `status`) VALUES
('010101', 'fadillah', 'MHltZjVETT0=', '2019-03-03', 'ki', 'pasuruan', '90909', '1'),
('1551510585', 'ridho', 'ZzNqSHZHZ2N2TjFCK3c9PQ==', '2019-03-05', 'surabaya', 'jombang', '08568798', '1'),
('1551512054', 'Yudhi', 'ZzNqSHZHZ2N2dGhNK2c9PQ==', '1986-06-29', 'Jombang RT.01', 'Malang', '085649591515', '0');

-- --------------------------------------------------------

--
-- Struktur dari tabel `e_barang`
--

CREATE TABLE IF NOT EXISTS `e_barang` (
  `id_barang` varchar(25) NOT NULL,
  `kd_brg` varchar(25) NOT NULL,
  `nm_barang` varchar(100) NOT NULL,
  `merk` varchar(100) NOT NULL,
  `satuan` varchar(25) NOT NULL,
  `hrg_jual` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `e_barang`
--

INSERT INTO `e_barang` (`id_barang`, `kd_brg`, `nm_barang`, `merk`, `satuan`, `hrg_jual`) VALUES
('01', '-', 'uang tunai 10.000', '-', 'lembar', 10000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `e_konfir`
--

CREATE TABLE IF NOT EXISTS `e_konfir` (
  `id` varchar(25) NOT NULL,
  `id_santri` varchar(25) NOT NULL,
  `no_rek` varchar(50) NOT NULL,
  `nominal` double NOT NULL,
  `atas_nm` varchar(100) NOT NULL,
  `tgl_transfer` date NOT NULL,
  `jm_transfer` time NOT NULL,
  `menyetujui` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `e_notif`
--

CREATE TABLE IF NOT EXISTS `e_notif` (
  `id` varchar(25) NOT NULL,
  `id_pengirim` varchar(25) NOT NULL,
  `id_penerima` varchar(25) NOT NULL,
  `isi` text NOT NULL,
  `tgl_notif` date NOT NULL,
  `tgl_baca` date NOT NULL,
  `status_notif` varchar(5) NOT NULL,
  `status_baca` varchar(5) NOT NULL,
  `jam_notif` time NOT NULL,
  `jam_baca` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `e_petugas`
--

CREATE TABLE IF NOT EXISTS `e_petugas` (
  `id_petugas` varchar(25) NOT NULL,
  `nm_petugas` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `alamat` longtext NOT NULL,
  `status` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `e_petugas`
--

INSERT INTO `e_petugas` (`id_petugas`, `nm_petugas`, `password`, `alamat`, `status`) VALUES
('1550831616', 'moch fadillah abullah', 'WGk3WTZvZ2xsbnJkYkE9PQ==', 'mojokerto kota', '1'),
('1551512410', 'fanon', 'ZzNqSHZHZ2N2dHhJL2c9PQ==', 'amerika', '1');

-- --------------------------------------------------------

--
-- Struktur dari tabel `e_santri`
--

CREATE TABLE IF NOT EXISTS `e_santri` (
  `id_santri` varchar(25) NOT NULL,
  `kd_emoney` varchar(10) NOT NULL,
  `nm_santri` varchar(100) NOT NULL,
  `pin` varchar(6) NOT NULL,
  `kelamin` varchar(25) NOT NULL,
  `password` varchar(100) NOT NULL,
  `tmp_lahir` varchar(100) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `hp_ortu` varchar(25) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `status` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `e_santri`
--

INSERT INTO `e_santri` (`id_santri`, `kd_emoney`, `nm_santri`, `pin`, `kelamin`, `password`, `tmp_lahir`, `tgl_lahir`, `hp_ortu`, `alamat`, `status`) VALUES
('1550548685', '2037060355', 'fadil', '123456', 'laki-laki', 'WGk3WTZvVWluM3JVYnc9PQ==', 'pasuruan', '2019-02-04', '085606812725', 'lumbang boro', '1'),
('1550578454', '1456324089', 'sahrul', '123456', 'laki-laki', 'WGk3WTZvVWhuM2paYmc9PQ==', 'jakarta', '2019-02-06', '085606812724', 'jaksel', '1'),
('1552209071', '1456085721', 'ratna dwi kurnia', '123456', 'perempuan', 'ZzNqSHYyOGR0ZGhPL3c9PQ==', 'tuban', '1998-02-08', '085606812728', 'desa cendoro kec palang kab tuban', '1');

-- --------------------------------------------------------

--
-- Struktur dari tabel `e_trans_keluar`
--

CREATE TABLE IF NOT EXISTS `e_trans_keluar` (
  `id` varchar(25) NOT NULL,
  `id_santri` varchar(25) NOT NULL,
  `kd_brg` varchar(25) NOT NULL,
  `jml` varchar(25) NOT NULL,
  `harga` int(6) NOT NULL,
  `jam` time NOT NULL,
  `tanggal` date NOT NULL,
  `keterangan` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `e_trans_keluar`
--

INSERT INTO `e_trans_keluar` (`id`, `id_santri`, `kd_brg`, `jml`, `harga`, `jam`, `tanggal`, `keterangan`) VALUES
('1552291403', '1550578454', '01', '1', 20000, '15:03:23', '2019-03-11', ''),
('1552293659', '1550578454', '01', '1', 10000, '15:40:59', '2019-03-11', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `e_trans_masuk`
--

CREATE TABLE IF NOT EXISTS `e_trans_masuk` (
  `id` varchar(25) NOT NULL,
  `id_santri` varchar(25) NOT NULL,
  `jam` time NOT NULL,
  `tanggal` date NOT NULL,
  `nominal` double NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `e_trans_masuk`
--

INSERT INTO `e_trans_masuk` (`id`, `id_santri`, `jam`, `tanggal`, `nominal`, `keterangan`) VALUES
('1551538847', '1550578454', '22:00:47', '2019-03-02', 80000, 'sukses'),
('1552224572', '1550578454', '20:29:32', '2019-03-10', 60000, ''),
('1552236843', '1550578454', '23:54:03', '2019-03-10', 100000, ''),
('1552293623', '1550578454', '15:40:23', '2019-03-11', 30000, ''),
('1552295823', '1550578454', '16:17:03', '2019-03-11', 2000, ''),
('1552296038', '1550578454', '16:20:38', '2019-03-11', 5500, ''),
('1552297120', '1550578454', '16:38:40', '2019-03-11', 9000, '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `log_history`
--

CREATE TABLE IF NOT EXISTS `log_history` (
  `id` char(30) NOT NULL,
  `data` varchar(50) NOT NULL,
  `operasi` varchar(50) NOT NULL,
  `keterangan` text NOT NULL,
  `id_user` char(30) NOT NULL,
  `tgl` date NOT NULL,
  `jam` time NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `log_history`
--

INSERT INTO `log_history` (`id`, `data`, `operasi`, `keterangan`, `id_user`, `tgl`, `jam`) VALUES
('', 'Hak Akses', 'Login', 'Login Berhasil', '010101', '0000-00-00', '00:00:00');

-- --------------------------------------------------------

--
-- Stand-in structure for view `saldo_santri`
--
CREATE TABLE IF NOT EXISTS `saldo_santri` (
`id_santri` varchar(25)
,`kd_emoney` varchar(10)
,`nm_santri` varchar(100)
,`pin` varchar(6)
,`jml_masuk` double
,`jml_keluar` double
,`saldo` double
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `v_keluar`
--
CREATE TABLE IF NOT EXISTS `v_keluar` (
`id_santri` varchar(25)
,`kd_emoney` varchar(10)
,`nm_santri` varchar(100)
,`jml_keluar` double
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `v_login`
--
CREATE TABLE IF NOT EXISTS `v_login` (
`id` varchar(25)
,`nama` varchar(100)
,`password` varchar(100)
,`status` varchar(25)
,`level` varchar(7)
,`folder` varchar(5)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `v_masuk`
--
CREATE TABLE IF NOT EXISTS `v_masuk` (
`id_santri` varchar(25)
,`kd_emoney` varchar(10)
,`nm_santri` varchar(100)
,`pin` varchar(6)
,`jml_masuk` double
);
-- --------------------------------------------------------

--
-- Struktur untuk view `saldo_santri`
--
DROP TABLE IF EXISTS `saldo_santri`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `saldo_santri` AS select `a`.`id_santri` AS `id_santri`,`a`.`kd_emoney` AS `kd_emoney`,`a`.`nm_santri` AS `nm_santri`,`a`.`pin` AS `pin`,`a`.`jml_masuk` AS `jml_masuk`,`b`.`jml_keluar` AS `jml_keluar`,(`a`.`jml_masuk` - `b`.`jml_keluar`) AS `saldo` from (`v_masuk` `a` join `v_keluar` `b` on((`a`.`id_santri` = `b`.`id_santri`))) group by `a`.`id_santri` order by `a`.`nm_santri`;

-- --------------------------------------------------------

--
-- Struktur untuk view `v_keluar`
--
DROP TABLE IF EXISTS `v_keluar`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_keluar` AS select `a`.`id_santri` AS `id_santri`,`a`.`kd_emoney` AS `kd_emoney`,`a`.`nm_santri` AS `nm_santri`,if(isnull(sum((`b`.`jml` * `b`.`harga`))),0,sum((`b`.`jml` * `b`.`harga`))) AS `jml_keluar` from (`e_santri` `a` left join `e_trans_keluar` `b` on((`a`.`id_santri` = `b`.`id_santri`))) group by `a`.`id_santri` order by `a`.`nm_santri`;

-- --------------------------------------------------------

--
-- Struktur untuk view `v_login`
--
DROP TABLE IF EXISTS `v_login`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_login` AS select `e_admin`.`id` AS `id`,`e_admin`.`nama` AS `nama`,`e_admin`.`password` AS `password`,`e_admin`.`status` AS `status`,'admin' AS `level`,'4dr' AS `folder` from `e_admin` union select `e_petugas`.`id_petugas` AS `id`,`e_petugas`.`nm_petugas` AS `nama`,`e_petugas`.`password` AS `password`,`e_petugas`.`status` AS `status`,'petugas' AS `level`,'9we' AS `folder` from `e_petugas` union select `e_santri`.`id_santri` AS `id`,`e_santri`.`nm_santri` AS `nama`,`e_santri`.`password` AS `password`,`e_santri`.`status` AS `status`,'santri' AS `level`,'10san' AS `folder` from `e_santri`;

-- --------------------------------------------------------

--
-- Struktur untuk view `v_masuk`
--
DROP TABLE IF EXISTS `v_masuk`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_masuk` AS select `a`.`id_santri` AS `id_santri`,`a`.`kd_emoney` AS `kd_emoney`,`a`.`nm_santri` AS `nm_santri`,`a`.`pin` AS `pin`,if(isnull(sum(`b`.`nominal`)),0,sum(`b`.`nominal`)) AS `jml_masuk` from (`e_santri` `a` left join `e_trans_masuk` `b` on((`a`.`id_santri` = `b`.`id_santri`))) group by `a`.`id_santri` order by `a`.`nm_santri`;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `e_admin`
--
ALTER TABLE `e_admin`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `e_barang`
--
ALTER TABLE `e_barang`
 ADD PRIMARY KEY (`id_barang`);

--
-- Indexes for table `e_konfir`
--
ALTER TABLE `e_konfir`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `e_notif`
--
ALTER TABLE `e_notif`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `e_petugas`
--
ALTER TABLE `e_petugas`
 ADD PRIMARY KEY (`id_petugas`);

--
-- Indexes for table `e_santri`
--
ALTER TABLE `e_santri`
 ADD PRIMARY KEY (`id_santri`);

--
-- Indexes for table `e_trans_keluar`
--
ALTER TABLE `e_trans_keluar`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `e_trans_masuk`
--
ALTER TABLE `e_trans_masuk`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `log_history`
--
ALTER TABLE `log_history`
 ADD PRIMARY KEY (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
