<?php $tabeldata = "TransaksiKeluar"; ?>
<div class="panel">
  <header class="panel-heading">
    <div class="panel-actions">
      <button type="button"
      data-toggle="modal" data-target="#ModalTambah"
      class="btn btn-round btn-success btn-sm" onclick="refresh()">Tambah Data
      </button>
    </div>
    <h3 class="panel-title">Data Transaksi Keluar</h3>
  </header>
  <div class="panel-body">
    <table class="table table-hover dataTable table-striped w-full" data-plugin="dataTable">
      <thead>
        <tr>
          <th style="width: 12%">ID</th>
          <th style="width: 10%">ID Santri</th>
          <th style="width: 10%">Kode barang</th>
          <th style="width: 13%">jumlah</th>
          <th style="width: 13%">harga</th>
          <th style="width: 12%">jam<br>tanggal</th>
          <th style="width: 13%">Tanggal Cair</th>
          <th style="width: 13%">Keterangan</th>
          <th style="width: 13%">Diterima</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $sql = "SELECT * FROM e_trans_keluar ORDER BY id";
        $tampil = mysqli_query($koneksi, $sql);
        while ($z = mysqli_fetch_array($tampil)){
        $id = $z["id"];
        $idsantri = $z["id_santri"];
        $barang = $z["kd_brg"];
        $jumlah = $z["jml"];
        $harga = $z["harga"];
        $jam = $z["jam"];
        $tanggal = $z["tanggal"];
        $x = $z["tgl_cair"];
        $keterangan = $z["keterangan"];
        $terima = $z["diterima"];
        
        echo "<tr>";
          echo "<td>$id</td>";
          echo "<td>$idsantri</td>";
          echo "<td>$barang</td>";
          echo "<td>$jumlah</td>";
          echo "<td>$harga</td>";
          echo "<td>$jam<br>".tgl_in($tanggal)."</td>";
          echo "<td>$x</td>";
          echo "<td>$keterangan</td>";
          echo "<td>$terima</td>";
            ?>
            <?php
          echo "</td>";
        echo "</tr>";
        }
        ?>
      </tbody>
    </table>
  </div>
  <!--MODAL TAMBAH DATA-->
  <div class="modal fade modal-success" id="ModalTambah" aria-hidden="true" role="dialog" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Tambah Data Transaksi Keluar</h4>
        </div>
        <form method="post">
          <div class="modal-body">
            <div class="row">
              <div class="form-group col-md-6">
                <label>ID</label>
                <input type="text" class="form-control" id="txtkd" maxlength="10" pattern="[1-9]" autocomplete="off" onchange="carisantri()" onkeyup="carisantri()">
              </div>
              <div class="form-group col-md-6">
                <label>ID Santri</label>
                <input type="text" class="form-control" id="txtidsantri"  placeholder="ex : 1234567890" required autocomplete="off" readonly>
              </div>
              <div class="form-group col-md-6">
                <label>Nama Santri</label>
                <input type="text" class="form-control" id="txtnama"  placeholder="ex : Fadil" required autocomplete="off" readonly>
              </div>
              <div class="form-group col-md-6">
                <label>Saldo Terakhir</label>
                <input type="text" class="form-control" id="txtsaldo" placeholder="100.000" required autocomplete="off" readonly>
              </div>
              <div hidden class="form-group col-md-6">
                <label>PIN</label>
                <input type="password" class="form-control" id="txtpin" placeholder="ex: ***" readonly>
              </div>
              <div class="form-group col-md-6">
                <label>PIN</label>
                <input type="password" class="form-control" id="txtpin2" placeholder="ex: ******" >
              </div>
              <div class="form-group col-md-6">
                <label>Jenis Kategori Uang</label>
                <select class="form-control" id="txtkategori"  onchange="saldo()" required>
                  <option value="">>>----Pilih Kategori----<<</option>
                  <?php
                  $sql = "SELECT * FROM e_barang WHERE nm_barang LIKE '%uang%'";
                  $tampil = mysqli_query($koneksi, $sql);
                  while ($z = mysqli_fetch_array($tampil)){
                  $id = $z["id_barang"];
                  $nm = $z["nm_barang"];
                  echo "<option value='$id'>$nm</option>";
                  }
                  ?>
                </select>
              </div>
              <div hidden class="form-group col-md-12">
                <label>Kode Barang</label>
                <input type="text" class="form-control" id="txtkdb" placeholder="kode barang" required autocomplete="off" style="font-size: 35px; height: 37px;" onchange="saldo()" readonly >
              </div>
              <div class="form-group col-md-6">
                <label>Keterangan</label>
                <input type="text" class="form-control" id="txtketerangan" placeholder="ex: keterangan">
              </div>
              <div class="form-group col-md-12">
                <label>Nominal</label>
                <input type="number" class="form-control" id="txtnominal"  placeholder="" required autocomplete="off" style="font-size: 35px; height: 37px;" onchange="saldo()">
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default btn-pure" data-dismiss="modal">Batal</button>
            <button type="button" class="btn btn-primary" onclick="simpandata()">Simpan</button>
          </div>
        </form>
      </div>
    </div>
  </div>
  <!--TAMBAH DATA PHP-->
  <?php
  if (isset($_REQUEST["btntambah"])){
  $j = strtotime(date("YmdHis"));
  $jam = date("H:i:s");
  $tgl = date("Y-m-d");
  $id = $_REQUEST["txtidsantri"];
  $kdb = $_REQUEST["txtkdb"];
  $nominal = $_REQUEST["txtnominal"];
  $keterangan = $_REQUEST["txtketerangan"];
  $pin1 = $_REQUEST["txtpin"];
  $pin2 = $_REQUEST["txtpin2"];
  if($pin1 != $pin2){
  echo "<script>
  swal({
  title: 'Simpan Gagal',
  text: 'Pin anda salah',
  type: 'error',
  showCancelButton: false,
  confirmButtonClass: 'btn-success',
  confirmButtonText: 'OK',
  closeOnConfirm: false
  });
  </script>";
  return;
  }
  $SQL = "INSERT INTO e_trans_keluar VALUES('$j','$id','$kdb','1','$nominal','$jam','$tgl','$keterangan','Ya')";
  $ProsesSimpan = mysqli_query($koneksi, $SQL);
  if ($ProsesSimpan){
  $isilog = "ID = $kd,\n ID Santri = $id,\n kode = $kdb,\n jumlah = $1,\n Nominal = $nominal,\n jam = $jam,\n tgl = $tgl,\n keterangan = $keterangan";
  tambah_log($tabeldata,'Tambah', $isilog, $id);
  echo "<script>
  swal({
  title: 'Simpan Berhasil',
  text: 'Data Berhasil di Tambahkan',
  type: 'success',
  showCancelButton: false,
  confirmButtonClass: 'btn-success',
  confirmButtonText: 'OK',
  closeOnConfirm: false
  }, function () {window.location = '';});
  </script>";
  } else {
  echo "<script>
  swal({
  title: 'Simpan Gagal',
  text: 'Periksa Kembali Isian Anda',
  type: 'error',
  showCancelButton: false,
  confirmButtonClass: 'btn-success',
  confirmButtonText: 'OK',
  closeOnConfirm: false
  });
  </script>";
  }
  }
  ?>
  
  <?php
  if (isset($_REQUEST["btnhapus"])){
  $j = $_REQUEST["txtidh"];
  $id = $_REQUEST["txtidsantrih"];
  $barang = $_REQUEST["txtbarangh"];
  $jml = $_REQUEST["txtjmlh"];
  $hrg = $_REQUEST["txthargah"];
  $jam = $_REQUEST["txtjamh"];
  $tanggal = $_REQUEST["txttanggalh"];
  $keterangan = $_REQUEST["txtketeranganh"];
  $SQL = "DELETE FROM e_trans_keluar WHERE id = '$j'";
  $ProsesSimpan = mysqli_query($koneksi, $SQL);
  if ($ProsesSimpan){
  $isilog = "ID = $j,\n ID Santri = $id,\n id_barang = $barang,\n Jumlah = $jml,\n Harga = $hrg,\n Jam = $jam,\n tanggal = $tanggal,\n keterangan = $keterangan";
  tambah_log($tabeldata,'Hapus', $isilog, $iduser);
  echo "<script>
  swal({
  title: 'Hapus Berhasil',
  text: 'Data Berhasil di Hapus',
  type: 'success',
  showCancelButton: false,
  confirmButtonClass: 'btn-success',
  confirmButtonText: 'OK',
  SantrieOnConfirm: false
  }, function () {window.location = '';});
  </script>";
  } else {
  echo "<script>
  swal({
  title: 'Hapus Gagal',
  texSantrieriksa Kembali Data Anda',
  type: 'error',
  showCancelButton: false,
  confirmButtonClass: 'btn-success',
  confirmButtonText: 'OK',
  closeOnConfirm: false
  });
  </script>";
  }
  }
  ?>
</div>
<script>
// fungsi simpan data
function simpandata(){
var id = $("#txtidsantri").val();
var m = $("#txtnominal").val();
var kategori = $("#txtkategori").val();
var saldo = $("#txtsaldo").val();
var kdb = $("#txtkdb").val();
var ket = $("#txtketerangan").val();
var pin = $("#txtpin").val();
var pin2 = $("#txtpin2").val();
if(id == "" ||  pin2 == "" || m == "" || m == 0){
swal({
title: 'Simpan Gagal',
text: 'Ada Isian yang Belum diisi',
type: 'error',
showCancelButton: false,
confirmButtonClass: 'btn-success',
confirmButtonText: 'OK',
closeOnConfirm: false
});
return;
}
if (parseInt(saldo) < parseInt(m)){
swal({
title: 'Simpan Gagal',
text: 'saldo anda tidak mencukupi',
type: 'error',
showCancelButton: false,
confirmButtonClass: 'btn-success',
confirmButtonText: 'OK',
closeOnConfirm: false
});
return;
}
if(pin != pin2){
swal({
title: 'Simpan Gagal',
text: 'PIN tidak Sesuai',
type: 'error',
showCancelButton: false,
confirmButtonClass: 'btn-success',
confirmButtonText: 'OK',
closeOnConfirm: false
});
return;
}
$.ajax({
url: "ajax/2222.php",
method: "POST",
data: {id: id, kategori: kategori, m: m, ket: ket},
cache: false,
success: function(x){
if(x == 1){
swal({
title: 'Simpan Berhasil',
text: 'Data Berhasil di Tambahkan',
type: 'success',
showCancelButton: false,
confirmButtonClass: 'btn-success',
confirmButtonText: 'OK',
closeOnConfirm: false
}, function(){
window.location = '';
});
}else{
swal({
title: 'Simpan Gagal',
text: 'Pengurangan Saldo Gagal',
type: 'error',
showCancelButton: false,
confirmButtonClass: 'btn-success',
confirmButtonText: 'OK',
closeOnConfirm: false
});
}
}
})
}
// fungsi cari santri
function carisantri(){
var a = $("#txtkd").val();
$.ajax({
url: "ajax/4700.php",
method: "POST",
data: {a: a},
cache: false,
success: function(x){
var r = x.split("|");
$("#txtidsantri").val(r[0]);
$("#txtnama").val(r[1]);
$("#txtsaldo").val(r[2]);
$("#txtpin").val(r[3]);
}
})
}
function saldo(){
var a = $("#txtkategori").val();
$.ajax({
url: "ajax/4445.php",
method: "POST",
data: {a: a},
cache: false,
success: function(x){
var y = x.split("|");
$("#txtnominal").val(y[0]);
$("#txtkdb").val(y[1]);
}
})
}

//refresh
 function refresh(){
$("#txtkd").val("");
$("#txtidsantri").val("");
$("#txtnama").val("");
$("#txtsaldo").val("");
$("#txtpin").val("");
$("#txtpin2").val("");
$("#txtkategori").val("");
$("#txtkdb").val("");
$("#txtketerangan").val("");
$("#txtnominal").val("");
}

function hapus(a, b, c, d, e, f){
$("#txtidh").val(a);
$("#txtidsantrih").val(b);
$("#txtbarangh").val(c);
$("#txtjmlh").val(d);
$("#txthargah").val(e);
$("#txtjamh").val(f);
$("#txttanggalh").val(g);
$("#txtketerangan").val(h);
}
</script>