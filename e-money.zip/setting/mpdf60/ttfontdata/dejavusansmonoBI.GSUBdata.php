<?php
$GSLuCoverage = array (
  0 => 
  array (
    0 => 
    array (
      330 => 0,
    ),
  ),
  1 => 
  array (
    0 => 
    array (
      1073 => 0,
    ),
  ),
  2 => 
  array (
    0 => 
    array (
      102 => 0,
    ),
  ),
);
?>