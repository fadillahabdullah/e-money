
<?php
include "../../setting/mpdf60/mpdf.php";
include "../../setting/koneksi.php";

$mpdf = new mPDF("utf-8","A4");
$tema = file_get_contents("../../tema/lap.css");
$mpdf->WriteHTML($tema,1);
ob_start();
$jenis = $_REQUEST["cbokategori"];
$keyword = $_REQUEST["txtkeyword"];
$tgl1 = $_REQUEST["tgl1"];
$tgl2 = $_REQUEST["tgl2"];
if($jenis == "ts"){
    $sql = "SELECT * FROM v_transaksi WHERE nm_santri LIKE '%$keyword%' AND tanggal BETWEEN '$tgl1' AND '$tgl2' ORDER BY tanggal, jam";
    $judul = "Data Transaksi Masuk dan Keluar";
}
if($jenis == "tm"){
    $sql = "SELECT * FROM v_transaksi WHERE nm_santri LIKE '%$keyword%' AND jenis='Masuk' AND (tanggal BETWEEN '$tgl1' AND '$tgl2') ORDER BY tanggal, jam";
    $judul = "Data Transaksi Masuk";
}
if($jenis == "tk"){
    $sql = "SELECT * FROM v_transaksi WHERE nm_santri LIKE '%$keyword%' AND jenis='Keluar' AND (tanggal BETWEEN '$tgl1' AND '$tgl2') ORDER BY tanggal, jam";
    $judul = "Data Transaksi Keluar";
}

$tampil = mysqli_query($koneksi, $sql);
?>
<!DOCTYPE html>
<html class="no-js css-menubar" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <meta name="description" content="bootstrap material admin template">
        <meta name="author" content="">
        <title>AL-GHOZALI| e-money</title>
        <link rel="shortcut icon" href="../../tema/assets/images/gzaicon.png">
        <!-- Stylesheets -->
    </head>
    <body>
    <img class="navbar-brand-logo navbar-brand-logo-normal" src="../../tema/assets/images/gza1.png" title="e-money">
    <center>AL-GHOZALI| e-money</center>    
    <hr>    
<h2 class="s">
    <b><i><?= $judul; ?></i></b>
</h2><hr>
<table border="1">
<tr style='background-color:maroon; color:white;'>
    <td class="putih tengah" width="50px"><b>ID</b></td>
    <td class="putih tengah" width="100px"><b>Nama Santri</b></td>
    <td class="putih tengah" width="100px"><b>Tanggal</b></td>
    <td class="putih tengah" width="100px"><b>Jam</b></td>
    <td class="putih tengah" width="100px"><b>Nominal Masuk</b></td>
    <td class="putih tengah" width="100px"><b>Nominal Keluar</b></td>
    <td class="putih tengah" width="100px"><b>Keterangan</b></td>
</tr>
<?php
    while ($z = mysqli_fetch_array($tampil)){
        $id = $z["id"];
        $idsantri = $z["id_santri"];
        $namasantri = $z["nm_santri"];
        $jam = $z["jam"];
        $tanggal = $z["tanggal"];
        $nominalm = $z["masuk"];
        $nominalk = $z["keluar"];
        $keterangan = $z["keterangan"];
?> 
        <tr>
            <td><?= $id; ?></td>
            <td><?= $namasantri; ?></td>
            <td><?= $tanggal; ?></td>
            <td><?= $jam; ?></td>
            <td><?= $nominalm; ?></td>
            <td><?= $nominalk; ?></td>
            <td><?= $keterangan; ?></td>

        </tr>
<?php
    }
echo "</table>";
$isi = ob_get_contents();   
ob_end_clean();
$mpdf->WriteHTML($isi);
$mpdf->Output("Laporan Transaksi.pdf", "I");
exit;
?>
    </body>
  </html>  

